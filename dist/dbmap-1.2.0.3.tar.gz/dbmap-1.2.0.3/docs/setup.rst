setup module
============

.. automodule:: setup
   :members:
   :undoc-members:
   :show-inheritance:
